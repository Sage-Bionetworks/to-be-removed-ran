# -*- coding: utf-8 -*-
"""
Created on Sat Jan  4 21:26:50 2014

@author: Florian Schwendinger
"""

myInt = 6
myDouble = 3.14
myString = "Test String!"
myUnicode = u'Äöüß 945 hdfji'
myList = [2, 3, "Hallo"]
myTuple = (1, 2, "Hallo")
mySet = set(myTuple)
