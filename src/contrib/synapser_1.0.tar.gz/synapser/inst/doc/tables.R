## ----collapse=TRUE-------------------------------------------------------
library(synapser)
synLogin()
# Create a new project
projectName<-sprintf("My unique project created on %s", format(Sys.time(), "%a %b %d %H%M%OS4 %Y"))
project<-Project(projectName)
project<-synStore(project)


## ----collapse=TRUE-------------------------------------------------------
cols <- list(
    Column(name='Name', columnType='STRING', maximumSize=20),
    Column(name='Chromosome', columnType='STRING', maximumSize=20),
    Column(name='Start', columnType='INTEGER'),
    Column(name='End', columnType='INTEGER'),
    Column(name='Strand', columnType='STRING', enumValues=list('+', '-'), maximumSize=1),
    Column(name='TranscriptionFactor', columnType='BOOLEAN'))

schema <- Schema(name='My Favorite Genes', columns=cols, parent=project)

## ----collapse=TRUE-------------------------------------------------------
genes<-data.frame(
	Name=c("foo", "arg", "zap", "bah", "bnk", "xyz"), 
	Chromosome=c(1,2,2,1,1,1), 
	Start=c(12345,20001,30033,40444,51234,61234),
	End=c(126000,20200,30999,41444,54567,68686),
	Strand=c('+', '+', '-', '-', '+', '+'),
	TranscriptionFactor=c(F,F,F,F,T,F))
genesFile<-tempfile()
write.csv(genes, file=genesFile, row.names=FALSE)

## ----collapse=TRUE-------------------------------------------------------
table<-Table(schema, genesFile)
table<-synStore(table)

## ----collapse=TRUE-------------------------------------------------------
results <- synTableQuery(sprintf("select * from %s where Chromosome='1' and Start < 41000 and End > 20000", table$schema$properties$id))
results$asDataFrame()

## ----collapse=TRUE-------------------------------------------------------
synDelete(project)

